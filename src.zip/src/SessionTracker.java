

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class SessionTracker
 */
@WebServlet("/SessionTracker")
public class SessionTracker extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	String message = "Hello User";
	private static Integer count = 0;
	public static final Integer EXP_TIME = 120;
	public static String SesidDelimiter = "@";
	public static String SvrLocal;
	public static ViewTable LocalView;
	public static final int KRes = 1;
	RPCClient client = new RPCClient();
	
	public SessionTracker() {
    	super();
    	
        //ip = getLocalAddr();
        //SvrLocal = "172.20.10.12";
        //String SvrMadhuri = "10.132.3.85";
        SvrLocal = GetServerIDLocal();
        
        ViewTuple newTuple = new ViewTuple(SvrLocal,ViewTable.STATUS_UP,System.currentTimeMillis());
        //ViewTuple newTuple1 = new ViewTuple(SvrMadhuri,ViewTable.STATUS_UP,System.currentTimeMillis());
       // ViewTuple newTuple2 = new ViewTuple("1.2.3.4",ViewTable.STATUS_UP,System.currentTimeMillis());
        
        LocalView = new ViewTable();
        LocalView.addTuple(newTuple);
        
        //LocalView.addTuple(newTuple1);
       
        // TODO Auto-generated constructor stub
        SynchronizedSessionMap ssmap = new SynchronizedSessionMap();
        try {
			System.out.println("IN INIt");
			Thread dt = new Thread(new GarbageThread(), "dt");
		    dt.setDaemon(true);
		    //dt.start();
		    Thread.sleep(500);
		} catch(InterruptedException e) {
			System.out.println("Exception In calling daemon");
		}
        //RPCServer server= new RPCServer();
       // server.ServerResponse();
        System.out.println("IN constructor.STart the server");
        Thread d = new Thread(new ServerThread());
        //dt.setDaemon(true);
        d.start();
        
      //Start a thread for Gossip
	    Thread gossiper = new Thread(new Gossip(SvrLocal));
	    gossiper.start();	 
    }
	
	protected String GetServerIDLocal()
	{
		String localIpAddress = null;
		InetAddress localInetAddress = null;
		String command = "/opt/aws/bin/ec2-metadata --public-ipv4";
		
		try{
			Runtime rt = Runtime.getRuntime();
			Process proc = rt.exec(command);
			
			String inputLine = "";
			BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
			
			while((inputLine = br.readLine()) != null)
			{
				System.out.println("inputLine" + inputLine);
				String[] inputString = inputLine.split(" ");
				localIpAddress = inputString[1];
			}
			
		}catch (IOException e){
			System.out.println(e.getMessage());
			try{
				// Try to get local server ip address, if its not ec2 instance
				localInetAddress = InetAddress.getByName(InetAddress.getLocalHost().getHostAddress());
				localIpAddress = localInetAddress.toString().substring(1);
			}catch (UnknownHostException e1){
				System.out.println(e1.getMessage());
			}
			
		}
	
		return localIpAddress;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Check if visitor is accessing url without a cookie (new/expired)
		//Perform garbage handling	
			 //ssmap.removeExpiredSessions();
			 
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.print(ServletUtilities.headWithTitle("CS5300PROJ1SESSION"));
		boolean newbie = true;
		Cookie[] cookies = request.getCookies();
		String oldCookieValue = null;
		if (cookies != null) {
			for(Cookie c: cookies) {
				if ((c.getName().equals("CS5300PROJ1SESSION"))) {
					newbie = false;
					oldCookieValue = c.getValue();
					break;
				}
			}
		}
		
		if (newbie) {
			//Handle new/expired session case here
			System.out.println("New request without cookie came");
			//Create new session
			int version = 0;
			
			MySession session = new MySession();
			synchronized (this){
			count++;
			String id = count+SesidDelimiter+SvrLocal;
			session.generateSession(id, message,version);
			/*ArrayList<String> test = new ArrayList();
			test.add("10.132.3.85");
			session.setlistOfIps(test);*/
			System.out.println("Inititating a the RPc client write.About to call sessionWriteClien");
			List<String> IpList = client.sessionWriteClient(id, session);
			
			System.out.println("List of IPS returned are: "+IpList.toString());
			session.setlistOfIps(IpList);
			SynchronizedSessionMap.addSession(session);
			}
			
			
			String debugValue = session.getSessionId()+"_Version="+session.getVersion()+"_ExpTime="+(session.getdiscardTime())+"_Location="+SvrLocal;
			String cookieValue = session.cookieValue();
			Cookie returnVisitorCookie = new Cookie("CS5300PROJ1SESSION",cookieValue);
			returnVisitorCookie.setMaxAge(EXP_TIME);
			response.addCookie(returnVisitorCookie);
			out.print("<body>\n"
					+ "<h1>"+message+"</h1>\n"
					+ "");
			out.print("<p>\n"
					+ "<form name=\"managesession\" method=\"POST\" action=\"SessionTracker\">\n"
					+"<input type=\"submit\" value=\"replace\" name=\"replace\"/> 	<input type=\"text\" name=\"message\"/> <br/><br/>\n"
					+"<input type=\"submit\" value=\"refresh\" name=\"refresh\"/><br/><br/>\n"
					+"<input type=\"submit\" value=\"logout\" name=\"logout\"/><br/><br/>\n"
					+"</form><br/>\n");
			out.print("<p>\n"
					+debugValue+"</p>\n");
			out.print("<p>\n"
					+cookieValue+"</p>\n");
			
			} else {
			//Handle old session case here
				int flag = 0;
				MySession session = null;
				String[] parts = oldCookieValue.split(MySession.CookieDelimiter);
				
				String id = parts[0].trim();
				for(int i = 2; i < parts.length;i++){
					if(parts[i].equals(SvrLocal))
					{
						session = SynchronizedSessionMap.getSessionById(id);
						System.out.println("Old Session Case: ID is "+id);
						System.out.println("Old Session Case: Version is"+ session.getVersion());
						if(session.getVersion()==Integer.parseInt(parts[1])){
							flag = 1;
							break;
						}
					}
				}
				
				MySession newSession = new MySession();
				if(flag != 1){
						System.out.println("Current SvrIP not found in Cookie List");
						clientRPC client = new clientRPC();
						String sesString = client.sessionReadClient(id);
						if(sesString.equals("notfound")){
							String newdebugValue = newSession.getSessionId()+"_Version="+newSession.getVersion()+"_ExpTime="+(newSession.getdiscardTime()+60000)+"_Location="+SvrLocal;
							String newcookieValue = newSession.cookieValue();
							Cookie newreturnVisitorCookie = new Cookie("CS5300PROJ1SESSION",newcookieValue);
							System.out.println("ERROR not found the session in server");
							newreturnVisitorCookie.setMaxAge(0);
							response.addCookie(newreturnVisitorCookie);
							out.print("<body>\n"
									+ "<h1>"+"Session Error"+"</h1>\n"
									+ "");
							out.print("<p>\n"
									+ "<form name=\"managesession\" method=\"POST\" action=\"SessionTracker\">\n"
									+"<input type=\"submit\" value=\"Login\" name=\"login\"/>\n"
									+"</form><br/>\n");
							
						} else{
							newSession = newSession.sesFromStr(sesString);
							System.out.println("Value received fromsession Read is : "+ sesString);
						}
				}else{
				//MySession newSession = SynchronizedSessionMap.getSessionById(id);
					newSession = session;
				}
				if(newSession != null){
				
					newSession.setVersion(newSession.getVersion()+1);
					newSession.setdiscardTime();
			
				if(request.getParameter("replace") != null){
					//Handle replace case here
					String message = request.getParameter("message");
					if(message.equals("")){
						newSession.setMessage("Hello User");
					} else{
						newSession.setMessage(message);
					}
					
					synchronized (this){
						List<String> IpList = client.sessionWriteClient(id, newSession);
						newSession.setlistOfIps(IpList);
						SynchronizedSessionMap.updateSessionEntryById(id,newSession);
					}
					
				}
				if(request.getParameter("refresh") != null){
					//Handle refresh case here
					
					synchronized (this){
						List<String> IpList = client.sessionWriteClient(id, newSession);
						newSession.setlistOfIps(IpList);
						SynchronizedSessionMap.updateSessionEntryById(id,newSession);
					}
			
				}
				if(request.getParameter("logout") != null){
					//handle logout case here
					SynchronizedSessionMap.removeSession(id);
					/*
					newSession = new MySession();
					newSession.generateSession(++count, message,0);
					synchronized (this){
					ssmap.addSession(newSession);
					}
					*/
				}
				
				
				String newdebugValue = newSession.getSessionId()+"_Version="+newSession.getVersion()+"_ExpTime="+(newSession.getdiscardTime()+60000)+"_Location="+SvrLocal;
				String newcookieValue = newSession.cookieValue();
		
				
				
				Cookie newreturnVisitorCookie = new Cookie("CS5300PROJ1SESSION",newcookieValue);
				if(request.getParameter("logout") != null){
					newreturnVisitorCookie.setMaxAge(0);
					response.addCookie(newreturnVisitorCookie);
					out.print("<body>\n"
							+ "<h1>"+"LoggedOut"+"</h1>\n"
							+ "");
					out.print("<p>\n"
							+ "<form name=\"managesession\" method=\"POST\" action=\"SessionTracker\">\n"
							+"<input type=\"submit\" value=\"Login\" name=\"login\"/>\n"
							+"</form><br/>\n");
					//out.print("<p>\n"
					//		+newcookieValue+"</p>\n");
					
				}
				else{
					newreturnVisitorCookie.setMaxAge(EXP_TIME);
				
				response.addCookie(newreturnVisitorCookie);
				out.print("<body>\n"
						+ "<h1>"+newSession.getMessage()+"</h1>\n"
						+ "");
				out.print("<p>\n"
						+ "<form name=\"managesession\" method=\"POST\" action=\"SessionTracker\">\n"
						+"<input type=\"submit\" value=\"replace\" name=\"replace\"/> 	<input type=\"text\" name=\"message\"/> <br/><br/>\n"
						+"<input type=\"submit\" value=\"refresh\" name=\"refresh\"/><br/><br/>\n"
						+"<input type=\"submit\" value=\"logout\" name=\"logout\"/><br/><br/>\n"
						+"</form><br/>\n");
				out.print("<p>\n"
						+newdebugValue+"</p>\n");
				out.print("<p>\n"
						+newcookieValue+"</p>\n");
				}
			
				
			}
				/*else{
					//Create new session
					int version = 0;
					MySession session = new MySession();
					id = count+SesidDelimiter+SvrLocal;
					session.generateSession(id, message,version);
					synchronized (this){
					SynchronizedSessionMap.addSession(session);
					}
					
					
					String debugValue = session.getSessionId()+"_Version="+session.getVersion()+"_ExpTime="+(session.getdiscardTime()+60000)+"_Location="+SvrLocal;
					String cookieValue = session.cookieValue();
					Cookie returnVisitorCookie = new Cookie("CS5300PROJ1SESSION",cookieValue);
					returnVisitorCookie.setMaxAge(EXP_TIME);
					response.addCookie(returnVisitorCookie);
					out.print("<body>\n"
							+ "<h1>"+message+"</h1>\n"
							+ "");
					out.print("<p>\n"
							+ "<form name=\"managesession\" method=\"POST\" action=\"SessionTracker\">\n"
							+"<input type=\"submit\" value=\"replace\" name=\"replace\"/> 	<input type=\"text\" name=\"message\"/> <br/><br/>\n"
							+"<input type=\"submit\" value=\"refresh\" name=\"refresh\"/><br/><br/>\n"
							+"<input type=\"submit\" value=\"logout\" name=\"submit\"/><br/><br/>\n"
							+"</form><br/>\n");
					out.print("<p>\n"
							+debugValue+"</p>\n");
				}*/
				
				out.println("<br/><p>"+this.LocalView+"<p><br/>"+SynchronizedSessionMap.map.toString());
				
			}
		
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request,response);
	}

}
