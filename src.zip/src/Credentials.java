

public class Credentials {

	public final static int Resilience = 1;								// Set the value of k resilience here
	public final static String aws_user_id = "AKIAIYF3PVZJOZHJX5CA";			// Set amazon userid
	public final static String aws_password = "gMzidAVmvn5uhzfcj1V97lskvddKOCdjYVmO+9ox";			// set amazon password
	
}
